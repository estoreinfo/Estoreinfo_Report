<?php
namespace Estoreinfo\Report\Controller\Index;

use Magento\Framework\App\Action\Action;

abstract class AbstractIndex extends Action
{
}